package com.example.cse225project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.File;
import java.io.FileWriter;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final EditText edt1 = findViewById(R.id.edt1);
        final Button clk = findViewById(R.id.clk);
        clk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!edt1.getText().toString().isEmpty()) {
                    File file = new File(MainActivity.this.getFilesDir(), "text");
                    if (!file.exists()) {
                        file.mkdir();
                    }
                    try {
                        File fl1 = new File(file, "sample");
                        FileWriter writer = new FileWriter(fl1);
                        writer.append(edt1.getText().toString());
                        writer.flush();
                        writer.close();
                    } catch (Exception e) { }
                }
            }
        });
    }
}
