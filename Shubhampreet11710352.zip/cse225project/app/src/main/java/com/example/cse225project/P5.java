package com.example.cse225project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class P5 extends AppCompatActivity implements Fragment1.FragmentAListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_p5);
    }
}
