package com.example.cse225project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class fragment_two extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragment_two);
    }
}
